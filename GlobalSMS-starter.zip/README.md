# GlobalSMS starter

A Next.js starter for a **daily (24-hour) virtual-number rental** business with NGN pricing and Paystack checkout architecture.

## Important: this is a starter, not a live phone-number service

The public site is real source code, but it intentionally does **not** invent phone numbers, fake SMS messages, accept payments, or confirm orders. Live operations remain disabled until you have:
1. A written commercial agreement with an SMS/voice provider that explicitly permits your business model and downstream customer rentals.
2. Provider API documentation and credentials for the specific countries and inbound-SMS capabilities you will sell.
3. A Paystack merchant account approved for the actual business activity.
4. Supabase project credentials and completed server-side order/authentication logic.
5. Privacy policy, terms, refund policy, support contact, abuse reporting and data-retention process.

Do not market numbers as suitable for WhatsApp, Facebook, Instagram, Telegram, banks or other verification services unless both the provider and the relevant platform expressly permit that use. A number's ability to receive ordinary SMS does not mean a third-party service will accept it for verification.

## Stack
- Next.js 14 / TypeScript
- Supabase (database and authentication to be completed)
- Paystack (NGN payments; test keys first)
- SMS provider adapter interface (`lib/sms-provider.ts`)
- Deploy on Vercel

## Run locally
1. Install Node.js 20 or later.
2. Extract this project.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local`.
5. Keep payment keys in test mode. Do not commit `.env.local`.
6. Run `npm run dev`.

## Required production implementation before taking money
- Add Supabase Auth and server-side ownership checks.
- Create pending orders on the server. Calculate prices only from server-side supplier pricing and your approved markup.
- Implement Paystack initialize transaction on the server using the stored order amount/email. Return the authorization URL.
- On webhook, verify `x-paystack-signature` using HMAC-SHA512 and timing-safe comparison; then verify the transaction with Paystack's API. Check reference, amount, NGN currency, customer/order, and idempotency before marking paid.
- Only after confirmed payment, call the contracted supplier's provisioning endpoint. Store the supplier rental ID and expiry.
- Receive supplier SMS webhooks; verify provider signatures and map messages to the correct active rental. Never expose other customers' messages.
- Release/expire numbers at the agreed 24-hour expiry; handle provider failure and refunds.
- Add rate limits, audit logs, fraud controls, admin RBAC, encryption, backups, monitoring and customer support.
- Test duplicate webhooks, delayed SMS, provider timeouts, refunds, expiry, and chargebacks.

## Deployment
1. Push the code to a private GitHub repository.
2. Import the repository into Vercel.
3. Add environment variables from `.env.example` in Vercel Project Settings.
4. Deploy the starter. The rent page will correctly show that live orders are not enabled yet.
5. Complete all production TODOs and obtain provider/payment approvals before enabling checkout.

## Revenue
Your gross margin is customer price minus provider charges. Net profit also subtracts Paystack fees, taxes, refunds, support, hosting and fraud losses. Do not promise a fixed profit or number availability.
