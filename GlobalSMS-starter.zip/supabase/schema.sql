-- Run in Supabase SQL Editor after reviewing and adapting to your provider.
create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null,
  email text not null,
  amount_kobo bigint not null check (amount_kobo > 0),
  currency text not null default 'NGN' check (currency = 'NGN'),
  status text not null default 'pending' check (status in ('pending','paid','provisioning','active','failed','refunded','expired')),
  paystack_reference text unique,
  provider_rental_id text unique,
  phone_number text,
  country_code text,
  starts_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.payment_events (
  id uuid primary key default gen_random_uuid(),
  provider_event_id text unique,
  order_id uuid references public.orders(id),
  event_type text not null,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.sms_messages (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  provider_message_id text unique,
  sender text,
  message_body text not null,
  received_at timestamptz not null default now()
);

-- Enable RLS. Add authenticated-user policies before exposing customer data.
alter table public.orders enable row level security;
alter table public.payment_events enable row level security;
alter table public.sms_messages enable row level security;

-- Do not add public read/write policies. Use server-side service-role access only
-- after verifying the authenticated customer owns the order.
