/**
 * Provider adapter contract.
 *
 * Connect only a supplier whose written terms permit your company to offer
 * end-user rentals/resale and whose supported use cases match your service.
 * Never assume that a country/number supports inbound SMS until the provider
 * confirms it for the specific number.
 */
export type NumberOffer = {
  providerOfferId: string;
  countryCode: string;
  countryName: string;
  capabilities: Array<"inbound_sms" | "voice">;
  retailPriceKobo: number;
  currency: "NGN";
};

export interface SmsProvider {
  listAvailableOffers(): Promise<NumberOffer[]>;
  provisionDailyRental(offerId: string, customerId: string): Promise<{
    providerRentalId: string;
    phoneNumber: string;
    expiresAt: string;
  }>;
  releaseRental(providerRentalId: string): Promise<void>;
}

export class ProviderNotConfiguredError extends Error {
  constructor() { super("SMS provider is not configured. No real number can be supplied yet."); }
}

export const smsProvider: SmsProvider = {
  async listAvailableOffers() { throw new ProviderNotConfiguredError(); },
  async provisionDailyRental() { throw new ProviderNotConfiguredError(); },
  async releaseRental() { throw new ProviderNotConfiguredError(); }
};
