import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GlobalSMS — Global number rentals",
  description: "Rent supported virtual numbers for legitimate business and personal communications."
};

export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body>{children}</body></html>;
}
