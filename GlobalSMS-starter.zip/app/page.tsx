import Link from "next/link";

const plans = [
  { name: "Daily", duration: "24 hours", price: "Price shown after number selection", detail: "A time-limited rental for supported incoming communications." },
];

export default function Home() {
  return <main className="wrap">
    <nav className="nav"><div className="brand">🌐 GlobalSMS</div><span className="pill">Daily rentals</span></nav>
    <section className="hero">
      <div className="tag">Global communications, made simpler</div>
      <h1>Rent a number.<br/>Stay connected.</h1>
      <p className="muted">Browse eligible virtual numbers for legitimate business and personal communications. Availability, SMS capability and local registration requirements vary by country.</p>
      <Link className="btn" href="/rent">Browse daily rentals</Link>
    </section>
    <div className="notice"><b>Service availability:</b> A number is offered only when an approved supplier confirms that it can be provisioned for your intended use. We do not guarantee acceptance by WhatsApp, social networks, banks or other third-party verification systems.</div>
    <section className="section">
      <h2>Simple daily rental</h2>
      <div className="grid">{plans.map(p=><article className="card" key={p.name}><span className="pill">24-hour plan</span><h3>{p.name} number rental</h3><p className="muted">{p.detail}</p><div className="price">₦ —</div><p className="muted">{p.price}</p><Link className="btn" href="/rent">Check availability</Link></article>)}</div>
    </section>
    <section className="section grid">
      <article className="card"><h3>Clear pricing</h3><p className="muted">See the total price in naira before paying.</p></article>
      <article className="card"><h3>Secure checkout</h3><p className="muted">Payments are verified server-side before an order is fulfilled.</p></article>
      <article className="card"><h3>Real supplier inventory</h3><p className="muted">No fabricated numbers or simulated incoming messages.</p></article>
    </section>
    <footer className="footer">GlobalSMS · Daily virtual number rentals · Support: configure your business support email before launch.</footer>
  </main>;
}
