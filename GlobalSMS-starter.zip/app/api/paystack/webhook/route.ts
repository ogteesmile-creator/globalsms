import { NextResponse } from "next/server";
import crypto from "node:crypto";

export async function POST(req: Request) {
  const secret = process.env.PAYSTACK_SECRET_KEY;
  const signature = req.headers.get("x-paystack-signature");
  const rawBody = await req.text();
  if (!secret || !signature) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const expected = crypto.createHmac("sha512", secret).update(rawBody).digest("hex");
  const a = Buffer.from(signature), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  const event = JSON.parse(rawBody);
  // IMPORTANT: Implement idempotent database processing:
  // 1) accept only charge.success; 2) verify reference, amount, currency and order status
  // against Paystack's server-side transaction verification endpoint;
  // 3) mark paid once; 4) only then request number provisioning.
  // Never provision from an unverified browser redirect.
  if (event?.event !== "charge.success") return NextResponse.json({ received: true });
  return NextResponse.json({ received: true, fulfillment: "disabled_until_provider_and_database_are_configured" });
}
