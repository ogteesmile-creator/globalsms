import { NextResponse } from "next/server";
import { z } from "zod";

const schema = z.object({ email: z.string().email(), amountKobo: z.number().int().positive().max(100_000_000), orderId: z.string().min(8) });

export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid checkout details" }, { status: 400 });
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return NextResponse.json({ error: "Payments are not configured" }, { status: 503 });

  // Production TODO: load the pending order from Supabase and derive amount/email
  // from the database. Never trust client-supplied amounts or order ownership.
  return NextResponse.json({ error: "Checkout is disabled until database-backed order validation is configured." }, { status: 503 });
}
