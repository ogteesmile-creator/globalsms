export default function RentPage() {
  return <main className="wrap">
    <a href="/">← GlobalSMS</a><h1>Choose a country</h1>
    <p className="muted">Live inventory appears here after you connect an approved SMS supplier API.</p>
    <div className="notice"><b>Not yet accepting orders.</b> This starter project intentionally does not display invented phone numbers or accept payments before supplier provisioning and payment verification are configured.</div>
    <section className="card section">
      <h3>Daily rental · 24 hours</h3>
      <p className="muted">The production version will show only countries and number types confirmed as available by your contracted provider.</p>
      <p>To activate: configure the provider adapter, Supabase database, Paystack account and legal/business requirements described in the README.</p>
    </section>
  </main>;
}
